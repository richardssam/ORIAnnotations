
import opentimelineio as otio
import datetime
from SyncEvent import SyncEvent

@otio.core.register_type
class PaintStart(SyncEvent):
    """A schema for the event system to denote when painting starts.
    timestamp is an ISO 8601 formatted string representing the time of the change.
    This is used to track when media changes occur in the timeline.
    """

    _serializable_label = "PaintStart.1"
    _name = "PaintStart"

    def __init__(
            self,
            source_index=0,
            uuid=None,
            friendly_name=None,
            participant_hash=None,
            rgba=None,
            type="color",
            brush="circle",
            visible=True,
            name=None,
            effect_name=None,
            layer_range=None,
            hold=None,
            ghost=None,
            ghost_before=None,
            ghost_after=None,
            timestamp=None 
        ):
        SyncEvent.__init__(self, timestamp)
        self.source_index = source_index
        self.uuid = uuid
        self.friendly_name = friendly_name
        self.participant_hash = participant_hash
        self.rgba = rgba
        self.type = type
        self.brush = brush
        self.visible = visible
        self.name = name
        self.effect_name = effect_name
        self.layer_range = layer_range
        self.hold = hold
        self.ghost = ghost
        self.ghost_before = ghost_before
        self.ghost_after = ghost_after

        if not isinstance(source_index, int):
            raise TypeError("source_index must be an integer")

        if not isinstance(rgba, list) or len(rgba) != 4 or not all(isinstance(x, (int, float)) for x in rgba):
            raise TypeError("rgba must be an list of numbers")

    source_index = otio.core.serializable_field(
        "source_index",
        required_type=int,
        doc="The index of the source media for the paint."
    )
    uuid = otio.core.serializable_field(
        "uuid",
        doc="The unique identifier for the paint event"
    )
    friendly_name = otio.core.serializable_field(
        "friendly_name",
        doc="The friendly artist name for the paint event creator"
    )
    participant_hash = otio.core.serializable_field(
        "participant_hash",
        doc="The unique identifier for the participant"
    )
    rgba = otio.core.serializable_field(
        "rgba",
        required_type=list,
        doc="The color of the paint event in RGBA format"
    )
    type = otio.core.serializable_field(
        "type",
        doc="The type of the paint event"
    )
    brush = otio.core.serializable_field(
        "brush",
        doc="The brush type of the paint event"
    )
    visible = otio.core.serializable_field(
        "visible",
        required_type=bool,
        doc="The visible type of the paint event"
    )
    layer_range = otio.core.serializable_field(
        "layer_range",
        required_type=otio.opentime.TimeRange,
        doc="The range of the layer for the paint event"
    )
    hold = otio.core.serializable_field(
        "hold",
        required_type=bool,
        doc="The hold of the paint event"
    )
    ghost = otio.core.serializable_field(
        "ghost",
        required_type=bool,
        doc="Is ghosting of the paint strokes enabled"
    )
    ghost_before = otio.core.serializable_field(
        "ghost_before",
        required_type=bool,
        doc="Number of frames to ghost before the current frame"
    )
    ghost_after = otio.core.serializable_field(
        "ghost_after",
        required_type=bool,
        doc="Number of frames to ghost after the current frame"
    )

    def __str__(self):
        
        return "MediaChange({})".format(
            repr(self.mediaReference)
        )

    def __repr__(self):
        return "otio.schemadef.SyncEvent.MediaChange(mediaReference={})".format(
            repr(self.mediaReference)
        )
    



@otio.core.register_type
class PaintVertex(otio.core.SerializableObject):
    """A schema for the definition of a point vertex in a paint stroke."""

    _serializable_label = "PaintVertex.1"
    _name = "PaintVertex"

    def __init__(
            self,
            x=0.0,
            y=0.0,
            size=1.0
        ):
        otio.core.SerializableObject.__init__(self)
        self.x = x
        self.y = y
        self.size = size

        if not isinstance(x, float):
            raise TypeError("x must be an float")
        if not isinstance(y, float):
            raise TypeError("y must be an float")
        if not isinstance(size, float):
            raise TypeError("size must be an float")
    x = otio.core.serializable_field(
        "x",
        required_type=float,
        doc="The x coordinate of the point vertex"
    )
    y = otio.core.serializable_field(
        "y",
        required_type=float,
        doc="The y coordinate of the point vertex"
    )
    size = otio.core.serializable_field(
        "size",
        required_type=float,
        doc="The size of the point vertex"
    )


    def __str__(self):
        
        return "PaintVertex({})".format(
            repr(self.x) + ", " + repr(self.y) + ", " + repr(self.size)
        )

    def __repr__(self):
        return "otio.schemadef.SyncEvent.PaintVertex(mediaReference={})".format(
            repr(self.mediaReference)
        )

@otio.core.register_type
class PaintPoint(SyncEvent):
    """A schema for the event system to denote when painting starts.
    timestamp is an ISO 8601 formatted string representing the time of the change.
    This is used to track when media changes occur in the timeline.
    """

    _serializable_label = "PaintPoint.1"
    _name = "PaintPoint"

    def __init__(
            self,
            source_index=0,
            uuid=None,
            layer_range=None,
            point=None,
            timestamp=None 
        ):
        SyncEvent.__init__(self, timestamp)
        self.source_index = source_index
        self.uuid = uuid
        self.layer_range = layer_range
        self.point = point

        if not isinstance(source_index, int):
            raise TypeError("source_index must be an integer")

        if not isinstance(point, list):
            print("Point type: ", type(point))
            raise TypeError("point must be an PaintVertex")

    source_index = otio.core.serializable_field(
        "source_index",
        required_type=int,
        doc="The index of the source media for the paint."
    )
    uuid = otio.core.serializable_field(
        "uuid",
        doc="The unique identifier for the paint event"
    )
    layer_range = otio.core.serializable_field(
        "layer_range",
        required_type=otio.opentime.TimeRange,
        doc="The range of the layer for the paint event"
    )
    point = otio.core.serializable_field(
        "point",
        required_type=list,
        doc="The vertex of the paint event"
    )

    def __str__(self):
        
        return "PaintPoint({})".format(
            repr(self.point)
        )

    def __repr__(self):
        return "otio.schemadef.SyncEvent.MediaChange(point={})".format(
            repr(self.point)
        )
    

@otio.core.register_type
class PaintEnd(SyncEvent):
    """A schema for the event system to denote when painting ends.
    timestamp is an ISO 8601 formatted string representing the time of the change.
    This is used to track when media changes occur in the timeline.
    """

    _serializable_label = "PaintEnd.1"
    _name = "PaintEnd"

    def __init__(
            self,
            uuid=None,
            point=None,
            timestamp=None
        ):
        SyncEvent.__init__(self, timestamp)
        self.uuid = uuid
        self.point = point


        if point is not None and not isinstance(point, list):
            raise TypeError("point must be a list of PaintVertex")

    uuid = otio.core.serializable_field(
        "uuid",
        doc="The unique identifier for the paint event"
    )

    point = otio.core.serializable_field(
        "point",
        required_type=PaintVertex,
        doc="The vertex of the paint event"
    )

    def __str__(self):
        return "PaintEnd({})".format(
            repr(self.point)
        )

    def __repr__(self):
        return "otio.schemadef.SyncEvent.PaintEnd(point={})".format(
            repr(self.point)
        )